<?php
/**
 * Ajax Callbacks
 *
 * @package Botiga
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
