<?php
/**
 * Displays footer site info
 *
 * @package Hair Spa Salon
 * @subpackage hair_spa_salon
 */

?>

<div class="site-info">
    <div class="container">
    	<p><?php hair_spa_salon_credit(); ?> <?php echo esc_html('By Themespride','hair-spa-salon'); ?> </p>
  </div>
</div>