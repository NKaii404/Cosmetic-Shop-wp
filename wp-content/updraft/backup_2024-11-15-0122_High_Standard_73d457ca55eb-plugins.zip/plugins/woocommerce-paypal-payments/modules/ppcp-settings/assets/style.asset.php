<?php return array('dependencies' => array(), 'version' => '3c3750c91a323c34631c');
