const TabStyling = () => {
	return <div>Styling tab</div>;
};

export default TabStyling;
