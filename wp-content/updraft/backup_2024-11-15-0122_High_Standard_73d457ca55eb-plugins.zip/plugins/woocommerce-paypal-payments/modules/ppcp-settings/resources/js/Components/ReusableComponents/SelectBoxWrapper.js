const SelectBoxWrapper = ( props ) => {
	return <div className="ppcp-r-select-box-wrapper">{ props.children }</div>;
};

export default SelectBoxWrapper;
