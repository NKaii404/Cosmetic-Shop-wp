const TabSettings = () => {
	return <div>Settings tab</div>;
};

export default TabSettings;
