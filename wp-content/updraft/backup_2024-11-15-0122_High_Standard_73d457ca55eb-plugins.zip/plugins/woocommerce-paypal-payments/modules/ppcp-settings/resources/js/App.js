import Settings from './Components/Screens/Settings';
export function App() {
	return (
		<div>
			<Settings />
		</div>
	);
}
