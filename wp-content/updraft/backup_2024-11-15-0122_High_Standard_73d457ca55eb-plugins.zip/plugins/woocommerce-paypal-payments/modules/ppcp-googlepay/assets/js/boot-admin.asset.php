<?php return array('dependencies' => array(), 'version' => '174b89850aa61dd5e9f3');
