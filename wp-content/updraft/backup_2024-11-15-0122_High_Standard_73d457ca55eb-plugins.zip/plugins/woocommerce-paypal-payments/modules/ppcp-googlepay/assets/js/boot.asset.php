<?php return array('dependencies' => array(), 'version' => 'c6a969012873e7227877');
