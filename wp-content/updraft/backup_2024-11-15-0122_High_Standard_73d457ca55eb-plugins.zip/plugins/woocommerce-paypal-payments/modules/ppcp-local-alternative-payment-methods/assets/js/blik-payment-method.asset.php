<?php return array('dependencies' => array('wc-blocks-registry'), 'version' => '57965fbc83e1bc82e412');
