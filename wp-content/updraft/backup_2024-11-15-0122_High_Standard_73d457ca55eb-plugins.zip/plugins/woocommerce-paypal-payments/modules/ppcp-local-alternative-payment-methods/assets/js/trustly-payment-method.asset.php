<?php return array('dependencies' => array('wc-blocks-registry'), 'version' => '6d299ff5625f49ccb013');
